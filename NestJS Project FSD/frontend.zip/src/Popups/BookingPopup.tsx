import React, { useState, useEffect } from 'react';
import { createBooking } from '../api/bookingApi';
import { getUserIdFromToken } from '../utils/jwtUtils';
import './BookingPopup.css';

interface BookingPopupProps {
  vehicle: any;
  onClose: () => void;
  onSuccess: () => void; // refresh vehicle list after booking
}

const BookingPopup: React.FC<BookingPopupProps> = ({
  vehicle,
  onClose,
  onSuccess,
}) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [paymentMethod, setPaymentMethod] =
    useState<'Cash' | 'Card'>('Cash');
  const [totalPrice, setTotalPrice] = useState(0);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Calculate total price
  useEffect(() => {
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      // Calculate days difference (inclusive of both start and end dates)
      const timeDiff = end.getTime() - start.getTime();
      const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;

      if (daysDiff > 0) {
        setTotalPrice(daysDiff * quantity * vehicle.pricePerDay);
      } else {
        setTotalPrice(0);
      }
    } else {
      setTotalPrice(0);
    }
  }, [startDate, endDate, quantity, vehicle.pricePerDay]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!startDate || !endDate) {
      setError('Please select start and end date');
      return;
    }

    if (new Date(endDate) < new Date(startDate)) {
      setError('End date cannot be before start date');
      return;
    }

    if (quantity < 1 || quantity > vehicle.quantity) {
      setError(`Quantity must be between 1 and ${vehicle.quantity}`);
      return;
    }

    setError('');
    setLoading(true);

    try {
      const userId = getUserIdFromToken();
      
      if (!userId) {
        setError('User not authenticated. Please log in again.');
        setLoading(false);
        return;
      }

      await createBooking({
        userId,
        vehicleId: vehicle.id,
        startDate,
        endDate,
        quantity,
        paymentMethod,
      });

      alert('Booking successful');
      onSuccess(); // refresh vehicle list
      onClose();
    } catch (err: any) {
      setError(
        err?.response?.data?.message || 'Booking failed'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="popup-overlay">
      <div className="popup">
        <h3>Book Vehicle: {vehicle.name}</h3>

        {error && <p className="error">{error}</p>}

        <form onSubmit={handleSubmit}>
          <label>Start Date</label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
          />

          <label>End Date</label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
          />

          <label>Quantity (Max {vehicle.quantity})</label>
          <input
            type="number"
            min={1}
            max={vehicle.quantity}
            value={quantity}
            onChange={(e) =>
              setQuantity(Number(e.target.value))
            }
          />

          <label>Payment Method</label>
          <div className="payment-methods">
            <label>
              <input
                type="radio"
                checked={paymentMethod === 'Cash'}
                onChange={() => setPaymentMethod('Cash')}
              />
              Cash
            </label>

            <label>
              <input
                type="radio"
                checked={paymentMethod === 'Card'}
                onChange={() => setPaymentMethod('Card')}
              />
              Card
            </label>
          </div>

          <p className="total">Total Price: ${totalPrice.toFixed(2)}</p>

          <div className="popup-buttons">
            <button type="submit" disabled={loading}>
              {loading ? 'Booking...' : 'Book Now'}
            </button>

            <button type="button" onClick={onClose}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BookingPopup;
