import axios from 'axios';

const API_BASE_URL = 'http://localhost:3000';

// Get user profile
export const getUserProfile = async (userId: number) => {
  try {
    const token = localStorage.getItem('access_token');
    const response = await axios.get(`${API_BASE_URL}/user/${userId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  } catch (error: any) {
    console.error('Error fetching user profile:', error);
    
    if (error.response) {
      const { status, data } = error.response;
      
      switch (status) {
        case 401:
          throw new Error('Unauthorized access. Please log in again.');
        case 404:
          throw new Error('User not found.');
        case 500:
          throw new Error('Server error. Please try again later.');
        default:
          throw new Error(data.message || 'Failed to fetch user profile');
      }
    } else if (error.request) {
      throw new Error('Network error. Please check your connection.');
    } else {
      throw new Error('An unexpected error occurred.');
    }
  }
};

// Update user profile (name, phone, email, password)
export const updateUser = async (userId: number, updateData: {
  name?: string;
  phone?: string;
  email?: string;
  currentPassword?: string;
  newPassword?: string;
}) => {
  try {
    const token = localStorage.getItem('access_token');
    const response = await axios.put(`${API_BASE_URL}/user/${userId}`, updateData, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });
    return response.data;
  } catch (error: any) {
    console.error('Error updating user:', error);
    
    if (error.response) {
      const { status, data } = error.response;
      
      switch (status) {
        case 401:
          throw new Error('Unauthorized access. Please log in again.');
        case 404:
          throw new Error('User not found.');
        case 400:
          throw new Error(data.message || 'Invalid data provided.');
        case 500:
          throw new Error('Server error. Please try again later.');
        default:
          throw new Error(data.message || 'Failed to update user');
      }
    } else if (error.request) {
      throw new Error('Network error. Please check your connection.');
    } else {
      throw new Error('An unexpected error occurred.');
    }
  }
};