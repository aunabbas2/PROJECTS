import axios from 'axios';

const API = 'http://localhost:3000/bookings';

export const createBooking = async (bookingData: {
  userId: number;
  vehicleId: number;
  quantity: number;
  paymentMethod: 'Cash' | 'Card';
  startDate: string;
  endDate: string;
}) => {
  try {
    const token = localStorage.getItem('access_token');

    const res = await axios.post(API, bookingData, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return res.data;
  } catch (error: any) {
    console.error('Error creating booking:', error);
    
    if (error.response) {
      const { status, data } = error.response;
      
      switch (status) {
        case 401:
          throw new Error('Unauthorized access. Please log in again.');
        case 400:
          throw new Error(data.message || 'Invalid booking data provided.');
        case 404:
          throw new Error('User or vehicle not found.');
        case 409:
          throw new Error('Not enough vehicles available.');
        case 500:
          throw new Error('Server error. Please try again later.');
        default:
          throw new Error(data.message || 'Failed to create booking');
      }
    } else if (error.request) {
      throw new Error('Network error. Please check your connection.');
    } else {
      throw new Error('An unexpected error occurred.');
    }
  }
};
