import axios from 'axios';

const API_URL = 'http://localhost:3000';

export interface SignupDto {
  email: string;
  password: string;
  name : string;
  phone : string;
}

export const signupUser = async (dto: SignupDto) => {
  const response = await axios.post(`${API_URL}/user`, dto, {
    headers: { 'Content-Type': 'application/json' },
  });
  return response.data;
};

