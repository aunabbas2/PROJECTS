import axios from 'axios';

const API_URL = 'http://localhost:3000/vehicles';

// GET all vehicles
export const getAllVehicles = async () => {
  const res = await axios.get(API_URL);
  return res.data;
};

// GET vehicles by type
export const getVehiclesByType = async (type: string) => {
  const res = await axios.get(`${API_URL}/type/${type}`);
  return res.data;
};



export const createVehicle = async (vehicle: any) => {
  const res = await axios.post(API_URL, vehicle);
  return res.data;
};
