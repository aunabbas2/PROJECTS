import { jwtDecode } from 'jwt-decode';

interface JwtPayload {
  sub: number; // user ID
  email: string;
  iat: number;
  exp: number;
}

export const getUserIdFromToken = (): number | null => {
  try {
    const token = localStorage.getItem('access_token');
    console.log('Token from localStorage:', token);
    if (!token) return null;

    const decoded: JwtPayload = jwtDecode(token);
    console.log('Decoded token:', decoded);
    return decoded.sub; // 'sub' typically contains the user ID
  } catch (error) {
    console.error('Error decoding token:', error);
    return null;
  }
};