import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import logo from '../assets/logo.jpg';
import '../components.css';

const Navbar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // Check if user is logged in
    const token = localStorage.getItem('access_token');
    setIsLoggedIn(!!token);
    
    // Listen for storage changes (e.g., login/logout from other tabs)
    const handleStorageChange = () => {
      const token = localStorage.getItem('access_token');
      setIsLoggedIn(!!token);
    };
    
    window.addEventListener('storage', handleStorageChange);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [location]);

  const handleLogoClick = (e: React.MouseEvent) => {
    e.preventDefault();
    // If user is logged in, go to dashboard, otherwise go to home
    if (isLoggedIn) {
      navigate('/Mainmenu');
    } else {
      navigate('/');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('access_token');
    setIsLoggedIn(false);
    navigate('/login');
  };


  return (
    <nav className="navbar">
      <div className="nav-container">
        <a href="/" onClick={handleLogoClick} className="nav-logo">
          <img 
            src={logo} 
            alt="Venture Auto Logo" 
            style={{ height:'40px', marginRight: '10px', borderRadius: '4px' }}
          />
           VENTURE AUTO
        </a>
        
        <div className="nav-links">
          {isLoggedIn ? (
            <>
              <Link to="/Mainmenu" className={`nav-link ${location.pathname === '/Mainmenu' ? 'active' : ''}`}>Dashboard</Link>
              <Link to="/vehicles" className={`nav-link ${location.pathname === '/vehicles' ? 'active' : ''}`}>Vehicles</Link>
              <Link to="/bookings" className={`nav-link ${location.pathname === '/bookings' ? 'active' : ''}`}>My Bookings</Link>
              <Link to="/profile" className={`nav-link ${location.pathname === '/profile' ? 'active' : ''}`}>Profile</Link>
              <button onClick={handleLogout} className="nav-link">Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className={`nav-link ${location.pathname === '/login' ? 'active' : ''}`}>Login</Link>
              <Link to="/signup" className={`nav-link ${location.pathname === '/signup' ? 'active' : ''}`}>Signup</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;