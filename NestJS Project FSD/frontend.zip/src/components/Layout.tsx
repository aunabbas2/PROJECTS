import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import '../components.css';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <Navbar />
      <main style={{ flex: 1, paddingTop: '20px' }}>
        {children}
      </main>
      <Footer />
    </div>
  );
};

export default Layout;