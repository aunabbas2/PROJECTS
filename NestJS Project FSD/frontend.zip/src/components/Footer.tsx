import React from 'react';
import '../components.css';

const Footer: React.FC = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-links">
          <a href="/" className="footer-link">Home</a>
          <a href="/vehicles" className="footer-link">Vehicles</a>
          <a href="/contact" className="footer-link">Contact</a>
          <a href="/privacy" className="footer-link">Privacy Policy</a>
        </div>
        <p className="footer-text">
          © {new Date().getFullYear()} Venture Auto. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;