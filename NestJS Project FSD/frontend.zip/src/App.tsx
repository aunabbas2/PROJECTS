import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Pages/Home';
import Login from './Pages/Login';
import Signup from './Pages/Signup';
import  MainMenu from './Pages/MainMenu';
import Vehicle from './Pages/Vehicle';
import Bookings from './Pages/Bookings';
import Profile from './Pages/Profile';
import Layout from './components/Layout';

const App: React.FC = () => {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path='/Mainmenu' element={<MainMenu/>}/>
          <Route path='/vehicles' element={<Vehicle/>}/>
          <Route path='/bookings' element={<Bookings/>}/>
          <Route path='/profile' element={<Profile/>}/>
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;
