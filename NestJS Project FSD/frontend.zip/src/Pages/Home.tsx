import React from 'react';
import { useNavigate } from 'react-router-dom';
import './home.css';

const Home: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="home-container">
      <div className="hero-section">
        <div className="hero-content">
          <h1>Welcome to Venture Auto</h1>
          <p>Experience premium vehicle rentals with competitive prices and exceptional service</p>
          
          <div className="button-container">
            <button className="button" onClick={() => navigate('/login')}>
              Login
            </button>
            <button className="button" onClick={() => navigate('/signup')}>
              Signup
            </button>
          </div>
        </div>
      </div>
      
      <div className="about-section">
        <div className="about-content">
          <h2>About Us</h2>
          <p>
            We are a leading vehicle rental company committed to providing our customers with 
            reliable, comfortable, and affordable transportation solutions. With a diverse fleet 
            of well-maintained vehicles, we cater to both business and leisure travelers.
          </p>
          <p>
            Our mission is to make vehicle rental simple, convenient, and stress-free. Whether 
            you need a car for a day, a week, or a month, we have the perfect vehicle to suit 
            your needs and budget.
          </p>
          
          <div className="features">
            <div className="feature">
              <h3>Wide Selection</h3>
              <p>Diverse fleet of vehicles from economy to luxury</p>
            </div>
            <div className="feature">
              <h3>Competitive Pricing</h3>
              <p>Best rates with no hidden fees</p>
            </div>
            <div className="feature">
              <h3>24/7 Support</h3>
              <p>Round-the-clock customer assistance</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
