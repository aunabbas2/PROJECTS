import React, { useState, useEffect } from 'react';
import { getUserIdFromToken } from '../utils/jwtUtils';
import { getUserProfile, updateUser } from '../api/userApi';
import './Profile.css';

interface User {
  id: number;
  email: string;
  name: string;
  phone: string;
}

const Profile: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Form states for updating profile
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  // Form states for UI
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [updateSuccess, setUpdateSuccess] = useState('');

  useEffect(() => {
    fetchUserProfile();
  }, []);

  const fetchUserProfile = async () => {
    try {
      const userId = getUserIdFromToken();
      if (!userId) {
        setError('User not authenticated. Please log in again.');
        setLoading(false);
        return;
      }

      const data = await getUserProfile(userId);
      setUser(data);
      setName(data.name);
      setPhone(data.phone);
      setEmail(data.email);
      setError('');
    } catch (err: any) {
      console.error('Error fetching user profile:', err);
      setError('Failed to fetch user profile: ' + (err.message || 'Unknown error'));
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const userId = getUserIdFromToken();
      if (!userId || !user) {
        setError('User not authenticated. Please log in again.');
        return;
      }
      
      const updatedUser = await updateUser(userId, { name, phone });
      
      setUser(updatedUser);
      setUpdateSuccess('Profile updated successfully!');
      setIsEditingProfile(false);
      
      // Clear success message after 3 seconds
      setTimeout(() => setUpdateSuccess(''), 3000);
    } catch (err: any) {
      console.error('Error updating profile:', err);
      setError('Failed to update profile: ' + (err.message || 'Unknown error'));
      console.error(err);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate passwords
    if (newPassword !== confirmPassword) {
      setError('New passwords do not match');
      return;
    }
    
    if (newPassword.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    
    try {
      const userId = getUserIdFromToken();
      if (!userId) {
        setError('User not authenticated. Please log in again.');
        return;
      }
      
      await updateUser(userId, {
        currentPassword,
        newPassword
      });
      setUpdateSuccess('Password changed successfully!');
      setIsChangingPassword(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      
      // Clear success message after 3 seconds
      setTimeout(() => setUpdateSuccess(''), 3000);
    } catch (err: any) {
      console.error('Error changing password:', err);
      setError('Failed to change password: ' + (err.message || 'Unknown error'));
      console.error(err);
    }
  };

  const handleEmailChange = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('Please enter a valid email address');
      return;
    }
    
    try {
      const userId = getUserIdFromToken();
      if (!userId || !user) {
        setError('User not authenticated. Please log in again.');
        return;
      }
      
      const updatedUser = await updateUser(userId, { email, currentPassword });
      
      setUser(updatedUser);
      setUpdateSuccess('Email updated successfully!');
      setCurrentPassword('');
      
      // Clear success message after 3 seconds
      setTimeout(() => setUpdateSuccess(''), 3000);
    } catch (err: any) {
      console.error('Error updating email:', err);
      setError('Failed to update email: ' + (err.message || 'Unknown error'));
      console.error(err);
    }
  };

  if (loading) {
    return <div className="profile-container">Loading...</div>;
  }

  return (
    <div className="profile-container">
      <h2>User Profile</h2>
      
      {error && <p className="error">{error}</p>}
      {updateSuccess && <p className="success">{updateSuccess}</p>}
      
      {user && (
        <div className="profile-content">
          {/* Profile Information */}
          <div className="profile-section">
            <h3>Personal Information</h3>
            {!isEditingProfile ? (
              <div className="profile-info">
                <p><strong>Name:</strong> {user.name}</p>
                <p><strong>Email:</strong> {user.email}</p>
                <p><strong>Phone:</strong> {user.phone}</p>
                <button 
                  className="edit-button"
                  onClick={() => setIsEditingProfile(true)}
                >
                  Edit Profile
                </button>
              </div>
            ) : (
              <form onSubmit={handleUpdateProfile} className="profile-form">
                <div className="form-group">
                  <label htmlFor="name">Name:</label>
                  <input
                    type="text"
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="phone">Phone:</label>
                  <input
                    type="tel"
                    id="phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                  />
                </div>
                
                <div className="form-buttons">
                  <button type="submit" className="save-button">
                    Save Changes
                  </button>
                  <button 
                    type="button" 
                    className="cancel-button"
                    onClick={() => {
                      setIsEditingProfile(false);
                      // Reset form values
                      setName(user.name);
                      setPhone(user.phone);
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>
          
          {/* Email Change Section */}
          <div className="profile-section">
            <h3>Change Email</h3>
            <form onSubmit={handleEmailChange} className="profile-form">
              <div className="form-group">
                <label htmlFor="email">New Email:</label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="email-password">Current Password:</label>
                <input
                  type="password"
                  id="email-password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  required
                />
              </div>
              
              <button type="submit" className="save-button">
                Update Email
              </button>
            </form>
          </div>
          
          {/* Password Change Section */}
          <div className="profile-section">
            <h3>Change Password</h3>
            {!isChangingPassword ? (
              <button 
                className="edit-button"
                onClick={() => setIsChangingPassword(true)}
              >
                Change Password
              </button>
            ) : (
              <form onSubmit={handleChangePassword} className="profile-form">
                <div className="form-group">
                  <label htmlFor="current-password">Current Password:</label>
                  <input
                    type="password"
                    id="current-password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="new-password">New Password:</label>
                  <input
                    type="password"
                    id="new-password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="confirm-password">Confirm New Password:</label>
                  <input
                    type="password"
                    id="confirm-password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                </div>
                
                <div className="form-buttons">
                  <button type="submit" className="save-button">
                    Change Password
                  </button>
                  <button 
                    type="button" 
                    className="cancel-button"
                    onClick={() => {
                      setIsChangingPassword(false);
                      // Reset password fields
                      setCurrentPassword('');
                      setNewPassword('');
                      setConfirmPassword('');
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Profile;