import React, { useState, useEffect } from 'react';
import { getUserIdFromToken } from '../utils/jwtUtils';
import { getUserBookings, cancelBooking } from '../api/bookingService';
import './Bookings.css';

interface Booking {
  id: number;
  vehicle: {
    id: number;
    name: string;
    image: string;
    pricePerDay: number;
  };
  quantity: number;
  totalPrice: number;
  paymentMethod: string;
  startDate: string;
  endDate: string;
}

const Bookings: React.FC = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchUserBookings();
  }, []);

  const fetchUserBookings = async () => {
    try {
      const userId = getUserIdFromToken();
      if (!userId) {
        setError('User not authenticated. Please log in again.');
        setLoading(false);
        return;
      }

      const data = await getUserBookings(userId);
      setBookings(data);
      setError('');
    } catch (err) {
      setError('Failed to fetch bookings');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelBooking = async (bookingId: number) => {
    try {
      await cancelBooking(bookingId);
      alert(`Booking ${bookingId} cancelled successfully!`);
      
      // Remove the booking from the list
      setBookings(bookings.filter(booking => booking.id !== bookingId));
    } catch (err) {
      alert('Failed to cancel booking');
      console.error(err);
    }
  };

  if (loading) {
    return <div className="bookings-container">Loading...</div>;
  }

  return (
    <div className="bookings-container">
      <div className="bookings-header">
        <h1>My Bookings</h1>
        <p>Manage your current and past vehicle reservations</p>
      </div>
      
      {error && <p className="error-message">{error}</p>}
      
      {loading ? (
        <p className="loading">Loading your bookings...</p>
      ) : bookings.length === 0 ? (
        <p className="no-bookings">You don't have any bookings yet.</p>
      ) : (
        <div className="bookings-list">
          {bookings.map(booking => (
            <div key={booking.id} className="booking-card">
              <div className="booking-header">
                <h3 className="booking-title">{booking.vehicle.name}</h3>
                <span className="booking-status confirmed">Confirmed</span>
              </div>
              
              <div className="booking-vehicle">
                <img 
                  src={`/assets/${booking.vehicle.image}`} 
                  alt={booking.vehicle.name} 
                  className="vehicle-image"
                />
                <div className="vehicle-info">
                  <h4>{booking.vehicle.name}</h4>
                  <p>Booking ID: {booking.id}</p>
                </div>
              </div>
              
              <div className="booking-details">
                <div className="detail-item">
                  <span className="detail-label">Dates</span>
                  <span className="detail-value">{new Date(booking.startDate).toLocaleDateString()} - {new Date(booking.endDate).toLocaleDateString()}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Quantity</span>
                  <span className="detail-value">{booking.quantity}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Total Price</span>
                  <span className="detail-value">${booking.totalPrice}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Payment Method</span>
                  <span className="detail-value">{booking.paymentMethod}</span>
                </div>
              </div>
              
              <div className="booking-actions">
                <button 
                  className="btn btn-danger"
                  onClick={() => handleCancelBooking(booking.id)}
                >
                  Cancel Booking
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Bookings;