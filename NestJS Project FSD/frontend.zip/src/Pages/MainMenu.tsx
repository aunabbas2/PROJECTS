import React from 'react';
import { useNavigate } from 'react-router-dom';
import './MainMenu.css';

const MainMenu: React.FC = () => {
  const navigate = useNavigate();

  // Menu items data
  const menuItems = [
    {
      id: 1,
      title: 'Browse Vehicles',
      description: 'Explore our fleet of premium vehicles',
      icon: '🚗',
      action: () => navigate('/vehicles'),
      color: 'blue'
    },
    {
      id: 2,
      title: 'My Bookings',
      description: 'View and manage your reservations',
      icon: '📅',
      action: () => navigate('/bookings'),
      color: 'green'
    },
    {
      id: 3,
      title: 'My Profile',
      description: 'Update your personal information',
      icon: '👤',
      action: () => navigate('/profile'),
      color: 'purple'
    }
  ];

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <h1 className="dashboard-title">VENTURE AUTO</h1>
        <p className="dashboard-subtitle">Welcome! How can we assist you today?</p>
      </div>
      
      <div className="dashboard-grid">
        {menuItems.map((item) => (
          <div 
            key={item.id} 
            className={`dashboard-card dashboard-card-${item.color}`}
            onClick={item.action}
          >
            <div className="card-icon">{item.icon}</div>
            <h3 className="card-title">{item.title}</h3>
            <p className="card-description">{item.description}</p>
            <div className="card-arrow">→</div>
          </div>
        ))}
      </div>
      
      <div className="dashboard-footer">
        <p>Need help? Contact our support team anytime</p>
      </div>
    </div>
  );
};

export default MainMenu;
