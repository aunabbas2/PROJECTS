import  { useEffect, useState } from 'react';
import { getAllVehicles, getVehiclesByType } from '../api/VehicleApi';
import './Vehicle.css';
import BookingPopup from '../Popups/BookingPopup';

const Vehicles = () => {
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [type, setType] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<any>(null);  
  
  const fetchVehicles = async () => {
    setLoading(true);
    try {
      let data;
      if (type) {
        data = await getVehiclesByType(type);
      } else {
        data = await getAllVehicles();
      }
      setVehicles(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVehicles();
  }, [type]);

  

  return (
    <div className="vehicle-container">
      <div className="vehicle-header">
        <h1>Our Vehicle Fleet</h1>
        <p>Browse our selection of quality vehicles for your next adventure</p>
      </div>
    
      <div className="vehicle-filters">
        <div className="filter-group">
          <div className="filter-item">
            <label>Filter by type:</label>
            <select value={type} onChange={(e) => setType(e.target.value)} className="filter-select">
              <option value="">All Vehicles</option>
              <option value="Sedan">Sedan</option>
              <option value="SUV">SUV</option>
              <option value="Hatchback">Hatchback</option>
            </select>
          </div>
        </div>
      </div>

      {loading ? (
  <p className="loading">Loading vehicles...</p>
) : vehicles.length === 0 ? (
  <p className="no-vehicles">No vehicles found. Please try another filter.</p>
) : (
  <div className="vehicle-grid">
    {vehicles.map((v) => (
      <div key={v.id} className="vehicle-card">
        <img src={`/assets/${v.image}`} alt={v.name} className="vehicle-image" />
        <div className="vehicle-details">
          <h3 className="vehicle-name">{v.name}</h3>
          <p className="vehicle-type">{v.type}</p>
          <div className="vehicle-price">
            <span className="price-label">Price per day</span>
            <span className="price-value">${v.pricePerDay}</span>
          </div>
          <div className="vehicle-stats">
            <div className="stat-item">
              <span className="stat-value">{v.quantity}</span>
              <span className="stat-label">Available</span>
            </div>
            <div className="stat-item">
              <span className="stat-value">{v.available ? 'Yes' : 'No'}</span>
              <span className="stat-label">In Stock</span>
            </div>
          </div>
          <button
            className={`btn ${v.quantity > 0 ? 'btn-primary' : 'btn-secondary'}`}
            disabled={v.quantity === 0}
            onClick={() => setSelectedVehicle(v)}
          >
            {v.quantity > 0 ? 'Book Now' : 'Out of Stock'}
          </button>
        </div>
      </div>
    ))}
  </div>
)}

{selectedVehicle && (
  <BookingPopup 
    vehicle={selectedVehicle}
    onClose={() => setSelectedVehicle(null)}
    onSuccess={() => { 
      fetchVehicles();
      setSelectedVehicle(null);
    }}  
  />
)}
    </div>
  );
};

export default Vehicles;
