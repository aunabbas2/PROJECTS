import { Controller, Post, UseGuards, Request, UnauthorizedException, Body, Logger } from '@nestjs/common' ;
import { AuthService } from './auth.service' ;
import { login } from "src/user/DTO/login.dto"

@Controller('auth')
export class AuthController {
constructor (private authService : AuthService ) {}


 
@Post('login')
 async login(@Body() loginDto: login) {
  Logger.log(`Login attempt for email: ${loginDto.email}`);
 const user = await this.authService .validateUser (loginDto.email, loginDto.password);
 Logger.log(`User validation result:`, user);

 if (!user) {
 throw new UnauthorizedException ('Invalid credentials' );
     }
     
 Logger.log(`Generating JWT token for user ID: ${user.id}`);
 return this.authService.login(user);
  }
}


