import { Injectable, UnauthorizedException, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UserService } from 'src/user/user.service';
import * as bcrypt from 'bcrypt';
import { PassThrough } from 'stream';

@Injectable()
export class AuthService {

    constructor(

        private userser: UserService,
        private jwtservice : JwtService,
    ){}


async validateUser(email: string , password : string): Promise<any>
{

    const user = await this.userser.getbyEmail(email)
    if(user &&  await bcrypt.compare( password, user.password )){
        const{ password , ...result } = user;
        return result
    }

    return null;
}


async login(user: any){
    Logger.log(`Creating JWT token for user: ${JSON.stringify(user)}`);
    const payload = { email: user.email, sub: user.id };
    Logger.log(`JWT payload: ${JSON.stringify(payload)}`);

    const token = this.jwtservice.sign(payload);
    Logger.log(`Generated JWT token: ${token.substring(0, 20)}...`);
    
    return {
        access_token: token
    }
}

}
