import { Body, Controller, Get, Post, Put, Param, UseGuards, ParseIntPipe } from '@nestjs/common';
import { UserService } from './user.service';
import { SignupDto } from './DTO/signuo.dto';
import { UpdateUserDto } from './DTO/update-user.dto';
import { JwtAuthGuard } from 'src/auth/Guards/jwt-auth.guard';
import { PartialType } from '@nestjs/mapped-types';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {
  }

  @Get()
  @UseGuards(JwtAuthGuard)
  getUsers() {
    return this.userService.getUsers();
  }

  @Get(':id')
  @UseGuards(JwtAuthGuard)
  getUserById(@Param('id', ParseIntPipe) id: number) {
    return this.userService.getUserById(id);
  }

  @Post()
  signup(@Body() dto: SignupDto) {
    return this.userService.signup(dto);
  }

  @Put(':id')
  @UseGuards(JwtAuthGuard)
  updateUser(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateUserData: UpdateUserDto
  ) {
    return this.userService.updateUser(id, updateUserData);
  }
}
