import { BadRequestException, Get, Injectable, UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { SignupDto } from './DTO/signuo.dto';
import { UpdateUserDto } from './DTO/update-user.dto';
import { Repository } from 'typeorm';
import { User } from './user.entity';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class UserService {

    constructor(
      @InjectRepository(User)

      private readonly userRepo : Repository<User>){}


      getUsers() {
        return this.userRepo.find();
      }

      async getUserById(id: number): Promise<User | null> {
        const user = await this.userRepo.findOne({ where: { id } });
        return user;
      }

     async getbyEmail(email: string) : Promise<User | null> {
        return this.userRepo.findOne({ where : { email }});
      }

      async signup(dto: SignupDto) {
        const hashedPassword = await bcrypt.hash(dto.password, 10);
        
        const user = this.userRepo.create({
          email: dto.email,
          password: hashedPassword,
          name: dto.name,
          phone: dto.phone,
        });
        
        return this.userRepo.save(user);
      }

      async updateUser(id: number, updateUserData: UpdateUserDto) {
        const user = await this.getUserById(id);
        if (!user) {
          throw new BadRequestException('User not found');
        }
        
        let updated = false;
        
        // Handle profile update (name and phone)
        if (updateUserData.name !== undefined) {
          user.name = updateUserData.name;
          updated = true;
        }
        
        if (updateUserData.phone !== undefined) {
          user.phone = updateUserData.phone;
          updated = true;
        }
        
        // Handle email change
        if (updateUserData.email !== undefined) {
          // For email change, we need current password
          if (updateUserData.currentPassword === undefined) {
            throw new BadRequestException('Current password is required to change email');
          }
          
          // Verify password
          const isPasswordValid = await bcrypt.compare(updateUserData.currentPassword, user.password);
          if (!isPasswordValid) {
            throw new UnauthorizedException('Invalid password');
          }
          
          // Check if email is already taken
          const existingUser = await this.getbyEmail(updateUserData.email);
          if (existingUser && existingUser.id !== id) {
            throw new BadRequestException('Email is already taken');
          }
          
          user.email = updateUserData.email;
          updated = true;
        }
        
        // Handle password change
        if (updateUserData.newPassword !== undefined) {
          // For password change, we need current password
          if (updateUserData.currentPassword === undefined) {
            throw new BadRequestException('Current password is required to change password');
          }
          
          // Verify current password
          const isPasswordValid = await bcrypt.compare(updateUserData.currentPassword, user.password);
          if (!isPasswordValid) {
            throw new UnauthorizedException('Invalid current password');
          }
          
          // Hash new password
          const hashedPassword = await bcrypt.hash(updateUserData.newPassword, 10);
          user.password = hashedPassword;
          updated = true;
        }
        
        if (!updated) {
          throw new BadRequestException('No valid update data provided');
        }
        
        return this.userRepo.save(user);
      }
}