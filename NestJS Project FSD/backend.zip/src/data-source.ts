import { DataSource } from 'typeorm';
import { User } from './user/user.entity';
import { Vehicle } from './vehicles/Entities/vehicle.entity';
import { Booking } from './booking/entity/booking.entity';

export default new DataSource({
type: 'postgres',
host: 'localhost' ,
port: 5432,
username: 'postgres',
password: 'bilal',
database: 'ProjectDB' ,
synchronize: true,
logging: true,
entities: [User,Vehicle,Booking],
migrations: ['src/migrations/*.ts' ],
});