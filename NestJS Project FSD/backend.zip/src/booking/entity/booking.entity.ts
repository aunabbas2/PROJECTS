import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { User } from 'src/user/user.entity';
import { Vehicle } from 'src/vehicles/Entities/vehicle.entity';

@Entity()
export class Booking {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, (user) => user.bookings, { onDelete: 'CASCADE' })
  user: User;

  @ManyToOne(() => Vehicle, (vehicle) => vehicle.bookings, { onDelete: 'CASCADE' })
  vehicle: Vehicle;

  @Column()
  quantity: number;

  @Column('decimal', { precision: 10, scale: 2 })
  totalPrice: number;

  @Column({ type: 'enum', enum: ['Cash', 'Card'] })
  paymentMethod: 'Cash' | 'Card';

  @Column()
  startDate: Date;

  @Column()
  endDate: Date;
}
