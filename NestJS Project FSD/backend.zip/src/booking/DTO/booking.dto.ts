import { IsNotEmpty, IsNumber, IsEnum, IsDateString } from 'class-validator';

export class BookingDto {
  @IsNumber()
  @IsNotEmpty()
  userId: number;

  @IsNumber()
  @IsNotEmpty()
  vehicleId: number;

  @IsNumber()
  @IsNotEmpty()
  quantity: number;

  @IsEnum(['Cash', 'Card'])
  @IsNotEmpty()
  paymentMethod: 'Cash' | 'Card';

  @IsDateString()
  @IsNotEmpty()
  startDate: Date;

  @IsDateString()
  @IsNotEmpty()
  endDate: Date;
}
