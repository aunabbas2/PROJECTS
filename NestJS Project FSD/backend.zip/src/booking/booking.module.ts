import { Module } from '@nestjs/common';
import { BookingsService } from './booking.service';
import { BookingsController } from './booking.controller';
import { Booking } from './entity/booking.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/user/user.entity';
import { Vehicle } from 'src/vehicles/Entities/vehicle.entity';

@Module({
  imports : [TypeOrmModule.forFeature([Booking,User,Vehicle])],
  controllers: [BookingsController],
  providers: [BookingsService],
})
export class BookingModule {}
