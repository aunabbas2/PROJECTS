import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Booking } from './entity/booking.entity';
import { Vehicle } from 'src/vehicles/Entities/vehicle.entity';
import { User } from 'src/user/user.entity';
import { BookingDto } from './DTO/booking.dto';

@Injectable()
export class BookingsService {
  constructor(
    @InjectRepository(Booking)
    private bookingRepo: Repository<Booking>,

    @InjectRepository(User)
    private userRepo: Repository<User>,

    @InjectRepository(Vehicle)
    private vehicleRepo: Repository<Vehicle>,
  ) {}

  async createBooking(dto: BookingDto): Promise<Booking> {
    const user = await this.userRepo.findOneBy({ id: dto.userId });
    if (!user) throw new BadRequestException('User not found');

    const vehicle = await this.vehicleRepo.findOneBy({ id: dto.vehicleId });
    if (!vehicle) throw new BadRequestException('Vehicle not found');

    if (vehicle.quantity < dto.quantity) {
      throw new BadRequestException('Not enough vehicles in stock');
    }

    vehicle.quantity -= dto.quantity;
    vehicle.available = vehicle.quantity > 0;
    await this.vehicleRepo.save(vehicle);

    // Calculate total price based on rental duration
    const startDate = new Date(dto.startDate);
    const endDate = new Date(dto.endDate);
    const timeDiff = endDate.getTime() - startDate.getTime();
    const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1; // +1 to include both start and end dates
    
    if (daysDiff <= 0) {
      throw new BadRequestException('End date must be after start date');
    }

    const totalPrice = dto.quantity * vehicle.pricePerDay * daysDiff;

    const booking = this.bookingRepo.create({
      user,
      vehicle,
      quantity: dto.quantity,
      totalPrice,
      paymentMethod: dto.paymentMethod,
      startDate: dto.startDate,
      endDate: dto.endDate,
    });

    return this.bookingRepo.save(booking);
  }

  async getUserBookings(userId: number): Promise<Booking[]> {
    return this.bookingRepo.find({
      where: { user: { id: userId } },
      relations: ['vehicle'],
    });
  }

  async cancelBooking(id: number): Promise<void> {
    // First, get the booking to restore vehicle quantity
    const booking = await this.bookingRepo.findOne({
      where: { id },
      relations: ['vehicle'],
    });

    if (!booking) {
      throw new BadRequestException('Booking not found');
    }

    // Restore vehicle quantity
    booking.vehicle.quantity += booking.quantity;
    booking.vehicle.available = booking.vehicle.quantity > 0;
    await this.vehicleRepo.save(booking.vehicle);

    // Delete the booking
    await this.bookingRepo.delete(id);
  }
}
