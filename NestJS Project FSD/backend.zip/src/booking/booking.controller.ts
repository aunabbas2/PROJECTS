import { Controller, Post, Body, Get, Param, ParseIntPipe, Delete } from '@nestjs/common';
import { BookingsService } from './booking.service';
import { BookingDto } from './DTO/booking.dto';

@Controller('bookings')
export class BookingsController {
  constructor(private bookingsService: BookingsService) {}

  @Post()
  createBooking(@Body() dto: BookingDto) {
    return this.bookingsService.createBooking(dto);
  }
  
  @Get('user/:userId')
  getUserBookings(@Param('userId', ParseIntPipe) userId: number) {
    return this.bookingsService.getUserBookings(userId);
  }
  
  @Delete(':id')
  cancelBooking(@Param('id', ParseIntPipe) id: number) {
    return this.bookingsService.cancelBooking(id);
  }
}
