import { Booking } from 'src/booking/entity/booking.entity';
import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class Vehicle {

  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  type: string;

  @Column()
  pricePerDay: number;

  @Column()
  image: string;

  @Column({ default: 2 })
  quantity: number;

  @Column({ default: true })
  available: boolean;

@OneToMany(() => Booking, (booking) => booking.vehicle)
bookings: Booking[];

}
