import { Get, Injectable, Post } from '@nestjs/common';
import { Repository } from 'typeorm';
import { Vehicle } from './Entities/vehicle.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { VehicleDto } from './DTO/vehicle.dto';



@Injectable()
export class VehiclesService {

constructor( 
    @InjectRepository(Vehicle)
     private readonly vehiclerepo : Repository<Vehicle>
){}


 findall(): Promise <Vehicle[]>{

    return this.vehiclerepo.find();
}



findbyType(type: string): Promise<Vehicle[] | null> {
  return this.vehiclerepo.find(type ? { where: { type } } : {}  );
}

insertVehicle(vehicle: VehicleDto) {
  const veh = this.vehiclerepo.create({
    ...vehicle,
    available:vehicle.quantity > 0
  });

  return this.vehiclerepo.save(veh);
}

async updateQuantity(id: number, quantity: number) {
  const vehicle = await this.vehiclerepo.findOne({ where: { id } });
  if (!vehicle) return null;

  vehicle.quantity = quantity;
  vehicle.available = quantity > 0;

  return this.vehiclerepo.save(vehicle);
}




}
