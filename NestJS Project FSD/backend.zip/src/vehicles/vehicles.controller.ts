import { Body, Controller, Get, Param, Post, Put, Query } from '@nestjs/common';
import { VehiclesService } from './vehicles.service';
import { VehicleDto } from './DTO/vehicle.dto';
import { Vehicle } from './Entities/vehicle.entity';

@Controller('vehicles')
export class VehiclesController {
  constructor(private readonly vehiclesService: VehiclesService) {}



@Put()
async updatequantity(@Query('id') id: number, @Query('quantity') quantity: number): Promise<Vehicle | null> {
    return this.vehiclesService.updateQuantity(id, quantity);   
}

@Get()
  getallVehicles()
  {
    return this.vehiclesService.findall()
  }

  @Get('type/:type')
  findbyType(@Param('type') type: string) {
    return this.vehiclesService.findbyType(type);
  }
  
  
  @Post()
  insertVehicle(@Body() vehicle : VehicleDto): Promise<Vehicle | null>
  {
    return this.vehiclesService.insertVehicle(vehicle)

  }
}
