import { IsInt, IsNotEmpty, IsPositive, Min } from 'class-validator';

export class VehicleDto {

  @IsNotEmpty()
  name: string;

  @IsNotEmpty()
  type: string;

  @IsPositive()
  pricePerDay: number;

  @IsNotEmpty()
  image: string;

  @IsInt()
  @Min(0)
  quantity: number;
}
