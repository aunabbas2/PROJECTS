import { MigrationInterface, QueryRunner } from "typeorm";

export class AddQuantityToVehicle1766066065697 implements MigrationInterface {
    name = 'AddQuantityToVehicle1766066065697'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "vehicle" ADD "quantity" integer NOT NULL DEFAULT '2'`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "vehicle" DROP COLUMN "quantity"`);
    }

}
