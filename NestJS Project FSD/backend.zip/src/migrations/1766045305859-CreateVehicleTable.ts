import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateVehicleTable1766045305859 implements MigrationInterface {
    name = 'CreateVehicleTable1766045305859'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "vehicle" ("id" SERIAL NOT NULL, "name" character varying NOT NULL, "type" character varying NOT NULL, "pricePerDay" integer NOT NULL, "image" character varying NOT NULL, "available" boolean NOT NULL DEFAULT true, CONSTRAINT "PK_187fa17ba39d367e5604b3d1ec9" PRIMARY KEY ("id"))`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP TABLE "vehicle"`);
    }

}
