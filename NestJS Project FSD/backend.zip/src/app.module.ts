import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './user/user.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './user/user.entity';
import { AuthModule } from './auth/auth.module';
import { JwtService } from '@nestjs/jwt';
import { VehiclesModule } from './vehicles/vehicles.module';
import { Vehicle } from './vehicles/Entities/vehicle.entity';
import { BookingModule } from './booking/booking.module';
import { Booking } from './booking/entity/booking.entity';

@Module({
  imports: [TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'postgres',
      password: 'bilal',
      database: 'ProjectDB',
      synchronize: true,
      entities: [User,Vehicle,Booking],
      }),
    UserModule,
    AuthModule,
    VehiclesModule,
    BookingModule],
  controllers: [AppController],
  providers: [AppService,JwtService],
})
export class AppModule {}
